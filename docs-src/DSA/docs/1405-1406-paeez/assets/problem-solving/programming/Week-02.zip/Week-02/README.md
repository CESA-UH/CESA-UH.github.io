## Requirements

- Python 3.12 or newer
- uv
- GCC
- Java JDK
- VS Code with the Jupyter extension

The notebooks use C and Java examples, so GCC and a Java JDK must be installed and available in the system PATH.