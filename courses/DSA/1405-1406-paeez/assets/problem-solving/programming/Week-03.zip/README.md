# DSA Practical — Week 3: Linked Lists

University of Hormozgan — Data Structures and Algorithms, Fall 2026

This session reviews singly, doubly, and circular linked lists, then practices four classic problems in Java:

1. Reverse a singly linked list
2. Rotate a singly linked list to the right by `k` positions
3. The Josephus problem on a circular linked list
4. Detect a cycle in a linked list

Each problem has a function template followed by a separate test cell. Implement the function, then run its test cell to check your solution.

## Repository Layout

```text
Week-03/
├── Lectures/
│   ├── 01_Linked_Lists.ipynb      # main worksheet
│   ├── josephus_n10_k2.html       # interactive Josephus walkthrough (N = 10, K = 2)
│   └── assets/                    # diagrams used by the notebook
├── pyproject.toml
├── uv.lock
└── README.md
```

## Requirements

- Python 3.12 or newer
- [uv](https://docs.astral.sh/uv/)
- Java JDK (both `javac` and `java` must be available in the system `PATH`)
- VS Code with the Jupyter extension

The notebook runs Java code through a small IPython cell magic (`%%java`) that calls `javac` and `java`. GCC is not needed for this week.

## Setup

1. Install the Python dependencies:
    
    ```bash
    uv sync
    ```
    
2. Check that the JDK is installed:
    
    ```bash
    javac -version
    java -version
    ```
    
3. Open the `Week-03` folder in VS Code, then open `Lectures/01_Linked_Lists.ipynb`.
    
4. Select the Python kernel from the `.venv` folder created by `uv sync`.
    

## How to Use the Notebook

1. Run the cell in **Section 1** once. It registers the `%%java` magic.
2. Run the shared setup cell in **Section 3** once. It defines `Node` and the test helpers.
3. For each problem, implement the Java function, run its cell, and then run the test cell below it. Each test prints `PASS` or `FAIL`.

Java cells start with one of these markers:

|Marker|Purpose|
|---|---|
|`// @setup`|Shared node definitions and helper methods|
|`// @solution`|A function implementation|
|`// @test`|Executable test statements|

Run the cells from top to bottom. If you restart the kernel, run Section 1 and Section 3 again before any other Java cell.

## Troubleshooting

| Problem                             | Fix                                                                                                      |
| ----------------------------------- | -------------------------------------------------------------------------------------------------------- |
| `A JDK is required` error           | Install a JDK and make sure `javac` and `java` are on `PATH`, then restart VS Code.                      |
| `Java compilation failed`           | Read the compiler message in the output. It points to the line with the error in your solution.          |
| Test cell cannot find your function | Run the solution cell first so it is compiled and stored.                                                |
| `Visualization file not found`      | Open the notebook from the `Lectures` folder so that `josephus_n10_k2.html` is in the working directory. |